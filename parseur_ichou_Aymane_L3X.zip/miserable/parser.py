#By Ichou Aymane
import re

#----------Initialisations---------------

separators = r'[.?!,;:()_\'\»]'

tome_1 = open ("tome_1.txt" , "r") 
tome_2 = open ("tome_2.txt" , "r") 
tome_3 = open ("tome_3.txt" , "r") 

liste_nom_propre = []
occurrences = []

#--------------Fonctions-----------------

#Fonction principale, qui va venir rechercher les noms propres dans un fichier texte donnée 
#Decoupe le fichier en phrase, puis en mots.
#Ecris dans deux liste associé , une qui garde les noms propres et l'autre les occurences.
def Search_Nom_Propre(file, separators) : 
    print("Début de la recherche des noms propres.")
    phrases = re.split(separators , file.read())
    for phrase in phrases:
        mots = phrase.split()
        for mot in mots:
            if(mot[0].isupper() and not mot == mots[0] and mot not in liste_nom_propre and not mot.isupper()):
                liste_nom_propre.append(mot)
                occurrences.append(1)
            elif mot in liste_nom_propre:
                index = liste_nom_propre.index(mot)
                occurrences[index] += 1
    print("Fin de la recherche des noms propres.")


#Fonction qui prend un nom de fichier de fichier de sortie et va écrire les noms associés au occurence dans le fichier donnée
def Write_in_File(nom_fichier):
    with open(nom_fichier, 'w', encoding='utf-8') as fichier:
        print("Début de l'écriture dans le fichier.")
        for i in range(len(liste_nom_propre)):
            temp = "Nom: " +  liste_nom_propre[i] + "| Occurrences:" + str(occurrences[i]) + "\n"
            fichier.write(temp)
        fichier.write("\nIl y a ")
        fichier.write(str(len(liste_nom_propre)))
        fichier.write(" noms propres. \n")
        print("Fin de l'écriture dans le fichier, résultats à la fin de celui-ci.")



#------------------Main------------------

#Changer ici pour changer le tome pris en compte: tome_1 ou tome_2 ou tome_3 
file_name = tome_1

Search_Nom_Propre(file_name, separators)
#Deboggage, permet de faire de l'affichage dans le terminal 
# for i in range(len(liste_nom_propre)): 
#     print("Nom: ", liste_nom_propre[i] , "| Occurrences:" , occurrences[i])
# print(len(liste_nom_propre))
Write_in_File(str(file_name) + "_res.txt")

