#Ichou Aymane 21007668
from bs4 import BeautifulSoup
import os


# Fonction qui va permettre l'extraction 
# Prend un fichier html en entrée
def extraction_file(in_file, out_file ): 
    #Ouverture du fichier à lire 
    with open(chemin_fichier, 'r', encoding='utf-8', errors='ignore') as file:
        html_content = file.read()

    # Créer un objet BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')

    # Rechercher toutes les balises <tr> dans le document
    rows = soup.find_all('tr')

    with open(out_file, 'w') as end_file:
        title = soup.find_all('h1')
        end_file.write(title[0].text + "\n") 
        for row in rows:
            # Recherche des balises <td> dans chaque ligne
            tds = row.find_all('td')
            for td in tds:
                # Recherche des balises <span> dans chaque cellule <td>
                spans = td.find_all('span')
                for span in spans:
                    # Recherche des balises <b> dans chaque balise <span>
                    bolds = span.find_all('b')
                    for bold in bolds:
                        # Afficher le contenu de la balise <b>
                        print("---------------------", bold.text, "---------------------\n")
                        end_file.write("-" + bold.text + "-" + "\n")
                    temp = span.text
                    print(span.text)
                    end_file.write(temp + "\n")

# extraction_file(file_to_open,out_file)

dossier = './res_scrap/html'
dossier_res = './res_scrap/txt/'

# Itérer sur les fichiers du dossier
for fichier in os.listdir(dossier):
    chemin_fichier = os.path.join(dossier, fichier)
    if os.path.isfile(chemin_fichier):
        with open(chemin_fichier, 'r') as file:
            print(chemin_fichier)
            print(fichier)
            extraction_file(chemin_fichier, dossier_res + fichier[:-5] + ".txt")

# Faire une fonction qui prend en parametre le nom du fichier et qui fait directement l'ecriture 
#dans un fichier resultat pris en parametre 