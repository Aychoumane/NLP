from pathlib import Path
import scrapy


class QuotesSpider(scrapy.Spider):
    name = "quotes"
    # Ajouter les autres URL ici au cas où il faut en ajouter 
    def start_requests(self):
        urls = [
            "https://www.paruvendu.fr/fiches-techniques-auto/renault-clio-ii/clio-1-5-dci-65-eco2-access-4-cv-diesel/10123792/",
            "https://www.paruvendu.fr/fiches-techniques-auto/renault-clio-ii/clio-1-2-60-eco2-dynamique-4-cv-essence/10119773/",
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        page = response.url.split("/")[-2]
        filename = f"res_scrap/html/quotes-{page}.html" 
        Path(filename).write_bytes(response.body)
        self.log(f"Saved file {filename}")