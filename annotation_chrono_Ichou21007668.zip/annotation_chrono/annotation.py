from unidecode import unidecode
#Biblio pour déconsidérer les accents , ex: unidecode(str1) et str1 = être -> etre 
from nltk.tokenize import word_tokenize, sent_tokenize
import sys

if len(sys.argv) != 2:
    print("Usage: python3 prog.py <nom_du_fichier>")
    sys.exit(1)

nom_fichier = sys.argv[1]

# Maintenant, vous pouvez utiliser 'nom_du_fichier' dans votre programme
print(f"Nom du fichier fourni : {nom_fichier}")


# ------------- Informations indiquant une date -----------

nbr_jour = list(range(1, 32))
determinant_jour = ["1er", "premier"]
nom_jour = ["lundi", "mardi" , "mercredi" , "jeudi" ,  "vendredi", "samedi" , "dimanche"]

nbr_mois = list(range(1, 12))
nom_mois = ["janvier", "fevrier", "mars", "avril" , "mai" , "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre"]

spe_date = ["prochain", "prochaine", "d'apres" , "d'avant", "avant", "apres", "suivant", "suivante", "precedent", "precedente", "dernier", "derniere"]
spe_ere_of_two  = ["avant j.c.", "apres j.c.", "avant l'hegire", "apres l'hegire", "guili"]
spe_ere_of_three = ["avant notre ere", "de notre ere", "apres notre ere", "de cette année", "de cet an"]
determinant_date = "le"
determinant_date_2 = "en"
mot_duree = ["jour", "jours" , "semaine", "semaines" , "annee" , "annees" , "week-end", "weekend"]
open_label = "<date>"
close_label = "</date>"

solo_word = ["hier", "aujourd'hui", "demain", "apres-demain"]
solo_word += nom_jour

# -----------------Fonctions auxiliaire--------------------

def bool_convert_and_check_in_nbr_jour_list(chaine):
	if(chaine.isdigit()):
		chaine = int(chaine)
		if(chaine in nbr_jour):
			return True
		else : 
			return False 
	else:
		return False

#--------Découpage du texte en mots, et en phrase----------
text = open (nom_fichier , "r") 
text = text.read()

words = word_tokenize(text)
sentences = sent_tokenize(text)

print(sentences)
#initialisation buffer 
buffer = ""

fichier_res = "balised_" + nom_fichier
res = open(fichier_res, "w")
#-------------- Main : Traitement du texte ----------------
for index in range (0, len(words)) : 

	# La date commence par un jour de la semaine 
	
	if((unidecode(words[index]).lower() in nom_jour)):
		buffer += words[index] + " "

		#Test pour vérifier qu'on va rentrer dans la condition d'après, et qu'on doit augmenter index
		# Car c'est possible de retrouver des mots seul indiquant une date dont les jours de la semaine
		if((unidecode(words[index+1]).lower() in spe_date) or (bool_convert_and_check_in_nbr_jour_list(words[index+1]))):
			index +=1 
		else:
			buffer = ""
		# Le mot d'apres est un nombre ou une spe_date 
		if((unidecode(words[index]).lower() in spe_date) or (bool_convert_and_check_in_nbr_jour_list(words[index]))): 
			# Le mot d'après est un nombre et est présent dans le nombre de jour possible
			if(bool_convert_and_check_in_nbr_jour_list(words[index])):
				buffer += words[index] + " "
				index +=1
				# Le mot d'après est un mois 
				if(unidecode(words[index]).lower() in nom_mois) : 
					buffer += words[index] + " "
					index +=1 
					#Le mot d'après une spé date ou une année 
					if((unidecode(words[index]).lower() in spe_date) or (words[index].isdigit()) ) :
						if(words[index].isdigit()):
							buffer += words[index] + " "
							index +=1
							# Le mot d'après est une spe ere 
							if(unidecode(words[index]).lower() in spe_ere ):
								buffer += words[index] 
								# ECRITURE 
								buffer = open_label + buffer + close_label
								res.write(buffer)
								buffer = ""
							# Le mot d'après n'est pas une spe ere 
							else : 
								buffer += words[index] 
								# ECRITURE 
								buffer = open_label + buffer + close_label
								res.write(buffer)
								buffer = ""


						#Etat terminal 
						else : 
							buffer += words[index] 
							# ECRITURE 
							buffer = open_label + buffer + close_label 
							res.write(buffer)
							buffer = ""


			#Etat terminal 
			else : 
				buffer += words[index] 
				# ECRITURE 
				buffer = open_label + buffer + close_label 
				res.write(buffer)
				buffer = ""

	buffer = "" 
 
	# L'expression commence par le 
	if((unidecode(words[index]).lower() == determinant_date)):
		buffer += words[index] + " "
		index  += 1
		# Le mot d'apres est un nom jour ou un nb jour ou un determinant jour "premier"
		
		if((unidecode(words[index]).lower() in nom_jour) 
			or (bool_convert_and_check_in_nbr_jour_list(words[index])) 
			or unidecode(words[index]).lower() in determinant_jour ) :
			if(unidecode(words[index]).lower() in nom_jour) : 
				buffer += words[index] + " "
				index +=1
				
			# Le mot trouvé est un nbr jour ou determinant jour, on les considere pareil 
			else: 
				
				buffer += words[index] + " "
				index +=1
				# Le mot trouvé est un mois 
				if(unidecode(words[index]).lower() in nom_mois):
					buffer += words[index]
					index +=1
					# Le mot trouvé est un spe_date 
					if(unidecode(words[index]).lower() in spe_date):
						buffer += " " + words[index] 
						index +=1
						buffer = open_label + buffer + close_label
						res.write(buffer)
						buffer = ""
					# Le mot trouvé est une année en chiffre 
					elif(unidecode(words[index]).isdigit()):
						buffer += " " + words[index] 
						index +=1
						temp2 = words[index] + " " + words[index+1]
						temp3 = temp2 + " " + words[index+2]
						#Etat terminal -> Le 1er janvier 2002 de notre ère
						if(unidecode(temp2).lower() in spe_ere_of_two or unidecode(temp3).lower() in spe_ere_of_three):
							if(unidecode(temp2).lower() in spe_ere_of_two): 
								buffer += " " + temp2 
								index +=2
								buffer = open_label + buffer + close_label
								res.write(buffer)
								buffer = ""
							else: 
								buffer += " " + temp3
								index +=3
								buffer = open_label + buffer + close_label
								res.write(buffer)
								buffer = ""

						#Etat terminal -> Le 1er janvier 2002 
						else:
							buffer = open_label + buffer + close_label
							res.write(buffer)
							buffer = ""
					# Etat terminal -> le 1er janvier 
					else: 
						buffer = open_label + buffer + close_label
						res.write(buffer)
						buffer = ""



	# Le mot trouvé est un mot unique qui indique une date 
	if((unidecode(words[index]).lower() in solo_word)) :
		buffer += words[index] 
		# ECRITURE 
		buffer = open_label + buffer + close_label 
		res.write(buffer)
		buffer = ""


	buffer = ""
	# La date commence par en 
	if(unidecode(words[index]).lower() == determinant_date_2): 
		buffer += words[index] + " "
		index  += 1
		#Le prochain mot est un nom_mois ou un nb_annee
		if((unidecode(words[index]).lower() in nom_mois) or (words[index].isdigit()) ) : 
			# Le mot est une année 
			if (words[index].isdigit()) : 
				buffer += words[index]
				index  += 1
				temp2 = words[index] + " " + words[index+1]
				temp3 = temp2 + " " + words[index+2]	
				#Vers un etat terminal -> En 2002 avant J.C. ou En 2002 de notre ère
				if(unidecode(temp2).lower() in spe_ere_of_two or unidecode(temp3).lower() in spe_ere_of_three):
					if(unidecode(temp2).lower() in spe_ere_of_two): 
						#Etat terminal 
						buffer += " " + temp2 
						index +=2
						buffer = open_label + buffer + close_label
						res.write(buffer)
						buffer = ""
					else: 
						#Etat terminal 
						buffer += " " + temp3
						index +=3
						buffer = open_label + buffer + close_label
						res.write(buffer)
						buffer = ""
				# En 2002 , tout court 
				else : 
					#Etat terminal 
					buffer = open_label + buffer + close_label
					res.write(buffer)
					buffer = ""

			# Le mot trouvé est un mois 
			if(unidecode(words[index]).lower() in nom_mois):
				buffer += words[index]
				index +=1
				# Le mot trouvé est un spe_date 
				if(unidecode(words[index]).lower() in spe_date):
					buffer += " " + words[index] 
					index +=1
					buffer = open_label + buffer + close_label
					res.write(buffer)
					buffer = ""
				# Le mot trouvé est une année en chiffre 
				elif(unidecode(words[index]).isdigit()):
					buffer += " " + words[index] 
					index +=1
					temp2 = words[index] + " " + words[index+1]
					temp3 = temp2 + " " + words[index+2]
					#Etat terminal -> En janvier 2002 de notre ère
					if(unidecode(temp2).lower() in spe_ere_of_two or unidecode(temp3).lower() in spe_ere_of_three):
						if(unidecode(temp2).lower() in spe_ere_of_two): 
							buffer += " " + temp2 
							index +=2
							buffer = open_label + buffer + close_label
							res.write(buffer)
							buffer = ""
						else: 
							buffer += " " + temp3
							index +=3
							buffer = open_label + buffer + close_label
							res.write(buffer)
							buffer = ""

					#Etat terminal -> En janvier 2002 
					else:
						buffer = open_label + buffer + close_label
						res.write(buffer)
						buffer = ""
				# Etat terminal -> En janvier 
				else: 
					buffer = open_label + buffer + close_label
					res.write(buffer)
					buffer = ""


	#res.write(words[index] + "  ")
#print(words)