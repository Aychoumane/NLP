Ichou Aymane 21007668
Ce code permet de faire un balisage xml d'un texte donné en argument dans le prompt, et extrait les dates dans un fichier "banalised"+ "nom_fichier.txt". 
Ce parser permet de detecter toutes les dates possible donné par le schéma présente dans le dossier.
Sauf les phrases de type "le jeudi 3 février"